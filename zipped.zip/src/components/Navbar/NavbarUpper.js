import React from 'react'
import Navbar from './Navbar'
import './Navbar.css'

const NavbarUpper = () => {
  return (
    <div className='navbar-upper-shadow'>
      <div className='navbar-upper'>

      </div>
      
    </div>
  )
}

export default NavbarUpper
