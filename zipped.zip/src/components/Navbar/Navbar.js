import React , {useState} from 'react'

import './Navbar.css'
import NavbarUpper from './NavbarUpper'
import logo from '../images/logo.png'

const Navbar = () => {


    const[click,  setClick] = useState(0)

    

    const clicked = ()=>{
        
        if(click==2 || click==1){
            setClick(0);
        }else{
            setClick(1)
        }
       
       
    }
  return (
    <div className='full-navbar'>
       
      <NavbarUpper/>
      <div className='navbar'>
        <div className='logo'>
            <img src={logo} />
            <i className="fa fa-bars" aria-hidden="true" onClick={ clicked}></i>
            
        </div>

        
        <div className="list-images">
        
        <ul className={click ? "hide show":"hidee hide"}>
            <li>PROGRAMS</li>
            <li>TRANSFORMATIONS</li>
            <li>BLOGS</li>
            <li>CONTACT</li>
            
            <li>TOOLS</li>
            <li>ABOUT</li>
            
        </ul>
         
        
          
        
      </div>
      </div>
    </div>
  )
}

export default Navbar 