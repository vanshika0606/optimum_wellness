import React from "react";
import "./steps.css";
import step1 from "../images/steps_1.png";

const Steps = () => {
  return (
    <div>
      <div className="rectangle">
       
      </div>
      <div className="half-ellipse-in-rectangle"></div>
      <div className="steps">
        <h3>How It Works</h3>

        <ul className="steps-list">
          <li>1</li>
          <li>2</li>
          <li>3</li>
          <li>4</li>
          <li>5</li>
        </ul>
        <h4>Step 1: Select your Programme</h4>

        <img src={step1} />
        <p>
          Fill up a preliminary assessment form and provide with relevant
          information about your lifestyle that's enable our experts to create
          the right customized programme for your goals.
        </p>
      </div>
    </div>
  );
};

export default Steps;
