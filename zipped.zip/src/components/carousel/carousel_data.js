import image1 from '../images/kusum.png';


const data = [
   {
        id:1,
        image:image1,
        story:"I was 93 kgs and I lost 21 kgs to reversed my PCOS and other health issues through a quantified nutrition and diet plan along with the appropriate workouts. Nutrition is often the missing key to a fitness journey. Without the proper nutrition, it is challenging to see the best results from workouts. I’m glad today I stand here as a bastion of hope for anyone who’s struggling to lose weight and feels entirely lost.Optimum wellness will significantly improve your health and wellbeing if you are determined to work upon yourself. Alan sir and his team are true heroes and are here to create change! Seeing their devotion and effort toward the exclusive clientele is quite inspiring. It's a fantastic and ever-growing platform for achieving optimal health."
   },
   {

        id:2,
        image:image1,
        story:"I was 93 kgs and I lost 21 kgs to reversed my PCOS and other health issues through a quantified nutrition and diet plan along with the appropriate workouts. Nutrition is often the missing key to a fitness journey. Without the proper nutrition, it is challenging to see the best results from workouts. I’m glad today I stand here as a bastion of hope for anyone who’s struggling to lose weight and feels entirely lost.Optimum wellness will significantly improve your health and wellbeing if you are determined to work upon yourself. Alan sir and his team are true heroes and are here to create change! Seeing their devotion and effort toward the exclusive clientele is quite inspiring. It's a fantastic and ever-growing platform for achieving optimal health."

   },
   {

        id:3,
        image:image1,
        story:"I was 93 kgs and I lost 21 kgs to reversed my PCOS and other health issues through a quantified nutrition and diet plan along with the appropriate workouts. Nutrition is often the missing key to a fitness journey. Without the proper nutrition, it is challenging to see the best results from workouts. I’m glad today I stand here as a bastion of hope for anyone who’s struggling to lose weight and feels entirely lost.Optimum wellness will significantly improve your health and wellbeing if you are determined to work upon yourself. Alan sir and his team are true heroes and are here to create change! Seeing their devotion and effort toward the exclusive clientele is quite inspiring. It's a fantastic and ever-growing platform for achieving optimal health."

   },
   {

    id:4,
    image:image1,
    story:"I was 93 kgs and I lost 21 kgs to reversed my PCOS and other health issues through a quantified nutrition and diet plan along with the appropriate workouts. Nutrition is often the missing key to a fitness journey. Without the proper nutrition, it is challenging to see the best results from workouts. I’m glad today I stand here as a bastion of hope for anyone who’s struggling to lose weight and feels entirely lost.Optimum wellness will significantly improve your health and wellbeing if you are determined to work upon yourself. Alan sir and his team are true heroes and are here to create change! Seeing their devotion and effort toward the exclusive clientele is quite inspiring. It's a fantastic and ever-growing platform for achieving optimal health."

   },
   {
    id:5,
    image:image1,
    story:"I was 93 kgs and I lost 21 kgs to reversed my PCOS and other health issues through a quantified nutrition and diet plan along with the appropriate workouts. Nutrition is often the missing key to a fitness journey. Without the proper nutrition, it is challenging to see the best results from workouts. I’m glad today I stand here as a bastion of hope for anyone who’s struggling to lose weight and feels entirely lost.Optimum wellness will significantly improve your health and wellbeing if you are determined to work upon yourself. Alan sir and his team are true heroes and are here to create change! Seeing their devotion and effort toward the exclusive clientele is quite inspiring. It's a fantastic and ever-growing platform for achieving optimal health."
   }
]


export default data;