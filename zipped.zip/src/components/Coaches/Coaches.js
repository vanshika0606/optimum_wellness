import React from 'react';
import './coaches.css';

const Coaches = () => {
  return (
    <div >
      <div className='meet-our-coaches'>MEET OUR COACHES
        <div className='coaches-line'>

        </div>
         </div>
    </div>
  )
}

export default Coaches
